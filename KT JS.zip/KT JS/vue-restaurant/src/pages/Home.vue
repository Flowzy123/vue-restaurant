<template>
  <div class="home">
    <div class="hero">
      <div class="overlay" />
      <div class="text-wrapper fade-in-up">
        <h1>Летний ресторан у моря</h1>
        <p class="description">
          Добро пожаловать в уголок вкуса и спокойствия. Здесь — шелест волн, аромат свежих блюд и тёплый бриз. Наш ресторан создаёт атмосферу уюта и расслабления у самого берега. Всё — от оформления до кухни — дышит летом, морем и лёгкостью.
        </p>
      </div>
    </div>
  </div>
</template>

<script setup>
// Ничего не нужно импортировать
</script>

<style scoped>
.home {
  width: 100%;
  height: 100vh;
  overflow: hidden;
  position: relative;
  font-family: 'Helvetica Neue', sans-serif;
}

/* 🏖 Фон с анимацией волн */
.hero {
  position: relative;
  width: 100%;
  height: 100%;
  background: url('/backgrounds/beach-wave.gif') center center / cover no-repeat;
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
  text-align: center;
}

.overlay {
  position: absolute;
  inset: 0;
  background: rgba(255, 255, 255, 0.4);
  backdrop-filter: blur(2px);
}

/* 🌞 Текст */
.text-wrapper {
  position: relative;
  z-index: 2;
  max-width: 800px;
  color: #2f1b00;
  padding: 20px;
  background: rgba(255, 255, 255, 0.7);
  border-radius: 20px;
  box-shadow: 0 4px 30px rgba(0, 0, 0, 0.05);
}

h1 {
  font-size: 2.8rem;
  font-weight: 700;
  font-family: 'Georgia', serif;
  margin-bottom: 20px;
  color: #4c2e05;
}

.description {
  font-size: 1.3rem;
  line-height: 1.7;
  color: #5c3a14;
}

/* ✨ Анимация появления */
.fade-in-up {
  opacity: 0;
  transform: translateY(20px);
  animation: fadeInUp 1.2s ease-out forwards;
}

@keyframes fadeInUp {
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
