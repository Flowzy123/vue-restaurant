<template>
  <div class="menu-page">
    <div class="menu-label">Летнее пляжное меню</div>

    <div class="image-center-wrapper">
      <div class="image-grid">
        <div v-for="(item, index) in items" :key="index" class="image-card">
          <img
            :src="item.image"
            :alt="item.title"
            class="main-image"
          />
          <div class="description-text">
            <h3>{{ item.title }}</h3>
            <p>{{ item.description }}</p>
          </div>
          <button class="btn-add-to-cart" @click="addToCart(item)">В корзину</button>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { store } from '../store.js'; // подключаем хранилище

const items = [
  {
    image: "/картинка1.jpg",
    title: "Краб в кокосовом молоке",
    description: "Мягкий краб в нежном соусе с нотками тропического рая.",
    price: 620,
  },
  {
    image: "/картинка2.jpg",
    title: "Салат «Океанский бриз»",
    description: "Свежесть овощей и морепродуктов с легкой цитрусовой заправкой.",
    price: 390,
  },
  {
    image: "/картинка3.jpg",
    title: "Гриль-кальмары",
    description: "Хрустящие кольца кальмара с лаймом и морской солью.",
    price: 470,
  },
  {
    image: "/картинка4.jpg",
    title: "Тартар из тунца",
    description: "Свежайший тунец с авокадо на хрустящем багете.",
    price: 520,
  },
  {
    image: "/картинка5.jpg",
    title: "Летние устрицы",
    description: "Подаются на льду с соусом манго и базиликом.",
    price: 680,
  },
  {
    image: "/картинка6.jpg",
    title: "Лосось на гриле",
    description: "Филе лосося с ананасовой сальсой и мятным соусом.",
    price: 590,
  },
];

function addToCart(item) {
  store.addToCart(item); // добавляем товар через store
}
</script>

<style scoped>
.menu-page {
  padding: 60px 40px 120px;
  max-width: 2559px;
  margin: 0 auto;
  background: linear-gradient(to bottom, #fffbe6, #e6f9ff);
  min-height: 120vh;
  box-sizing: border-box;
  display: flex;
  flex-direction: column;
  align-items: center;
}

.menu-label {
  max-width: 1000px;
  margin: 0 auto 50px;
  text-align: center;
  font-size: 2.4rem;
  font-weight: 700;
  color: #a8641a;
  user-select: none;
  font-family: 'Georgia', serif;
  padding-left: 0;
}

.image-center-wrapper {
  display: flex;
  justify-content: center;
  width: 100%;
  max-width: 2000px;
  box-sizing: border-box;
  padding-bottom: 60px;
}

.image-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
  gap: 50px 40px;
  width: 100%;
  box-sizing: border-box;
}

.image-card {
  position: relative;
  display: flex;
  flex-direction: column;
  align-items: center;
  border-radius: 20px;
  padding: 20px 20px 80px;
  background-color: #fffaf2;
  box-shadow: 0 10px 25px rgba(255, 198, 107, 0.15);
  transition: transform 0.3s ease, box-shadow 0.3s ease;
  user-select: none;
  box-sizing: border-box;
}

.image-card:hover {
  transform: translateY(-5px);
  box-shadow: 0 15px 35px rgba(255, 198, 107, 0.25);
}

.main-image {
  width: 100%;
  height: 250px;
  object-fit: cover;
  border-radius: 15px;
  margin-bottom: 20px;
  user-select: none;
}

.description-text {
  padding: 10px 15px 0;
  border-radius: 10px;
  width: 100%;
  box-sizing: border-box;
  color: #4b2e13;
  font-family: 'Arial', sans-serif;
  text-align: center;
}

.description-text h3 {
  margin: 0 0 8px 0;
  font-size: 1.4rem;
  font-weight: 700;
  color: #a8641a;
}

.description-text p {
  margin: 0;
  font-size: 1rem;
  line-height: 1.6;
  color: #6d4c2d;
}

.btn-add-to-cart {
  position: absolute;
  bottom: 20px;
  right: 20px;
  padding: 10px 20px;
  font-size: 1rem;
  background-color: #ffb347;
  color: white;
  border: none;
  border-radius: 10px;
  cursor: pointer;
  box-shadow: 0 4px 12px rgba(255, 167, 38, 0.3);
  transition: background-color 0.3s ease;
  user-select: none;
}

.btn-add-to-cart:hover {
  background-color: #e2941d;
}
</style>
