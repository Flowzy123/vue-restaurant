<template>
  <div class="rules-page">
    <h1>Правила ресторана</h1>
    <p class="intro">
      Добро пожаловать в наш летний ресторан! Пожалуйста, ознакомьтесь с нашими правилами:
    </p>
    <ul>
      <li>Приходите в удобной летней одежде.</li>
      <li>Уважайте других гостей и персонал.</li>
      <li>Заказ принимается только с помощью нашего сайта.</li>
      <li>Дети до 12 лет обслуживаются только в сопровождении взрослых.</li>
      <li>Оплата возможна наличными или картой.</li>
      <li>Для отмены заказа свяжитесь с нами минимум за 1 час до времени брони.</li>
      <li>Мы заботимся о качестве продуктов и экологичности.</li>
      <li>Если у вас есть аллергии или особые пожелания, сообщите нам заранее.</li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'Rules',
};
</script>

<style scoped>
.rules-page {
  max-width: 700px;
  margin: 3rem auto;
  padding: 2rem 2.5rem;
  background: #fff8dc;
  border-radius: 16px;
  box-shadow: 0 4px 20px rgba(250, 130, 49, 0.25);
  color: #444;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  line-height: 1.6;
  user-select: text;
}

.rules-page h1 {
  color: #fa8231;
  font-weight: 700;
  font-size: 2.5rem;
  margin-bottom: 1rem;
  text-align: center;
  text-shadow: 1px 1px 3px rgba(250, 130, 49, 0.4);
}

.rules-page .intro {
  font-size: 1.2rem;
  color: #6b4e16;
  margin-bottom: 1.5rem;
  text-align: center;
  font-style: italic;
}

.rules-page ul {
  list-style: inside disc;
  padding-left: 0;
  font-size: 1.15rem;
  color: #555;
  border-left: 4px solid #fa8231;
  padding-left: 1rem;
}

.rules-page li {
  margin-bottom: 0.8rem;
  transition: color 0.3s ease;
}

.rules-page li:hover {
  color: #fa8231;
  cursor: default;
}
</style>
