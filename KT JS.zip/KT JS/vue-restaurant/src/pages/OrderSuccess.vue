<template>
  <div class="order-success">
    <h1>🎉 Спасибо за заказ!</h1>
    <p>Мы уже готовим и скоро доставим его вам 🛵</p>
    <router-link to="/">Вернуться на главную</router-link>
  </div>
</template>

<script>
export default {
  name: 'OrderSuccess'
};
</script>

<style scoped>
.order-success {
  max-width: 600px;
  margin: 0 auto;
  text-align: center;
  padding: 3rem;
  background: #f0fff4;
  border-radius: 16px;
}

h1 {
  font-size: 2rem;
  color: #2e7d32;
  margin-bottom: 1rem;
}

p {
  font-size: 1.2rem;
  margin-bottom: 2rem;
}

a {
  text-decoration: none;
  color: #0077cc;
}
</style>
