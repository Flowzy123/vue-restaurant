<template>
  <div class="checkout-page">
    <h1>🧾 Оформление заказа</h1>

    <form @submit.prevent="submitOrder" class="checkout-form">
      <div class="form-group">
        <label for="name">Имя:</label>
        <input id="name" v-model="name" type="text" required />
      </div>

      <div class="form-group">
        <label for="phone">Телефон:</label>
        <input
          id="phone"
          ref="phoneInput"
          v-model="phone"
          type="tel"
          required
          placeholder="+7 (___) ___-__-__"
        />
      </div>

      <div class="form-group">
        <label for="address">Адрес доставки:</label>
        <textarea id="address" v-model="address" required></textarea>
      </div>

      <button type="submit" class="submit-btn">Подтвердить заказ</button>
    </form>

    <p v-if="errorMessage" class="error">{{ errorMessage }}</p>
  </div>
</template>

<script>
import IMask from 'imask';

export default {
  name: 'Checkout',
  data() {
    return {
      name: '',
      phone: '',
      address: '',
      errorMessage: ''
    };
  },
  mounted() {
    this.phoneMask = IMask(this.$refs.phoneInput, {
      mask: '+{7} (000) 000-00-00'
    });
  },
  beforeUnmount() {
    if (this.phoneMask) {
      this.phoneMask.destroy();
    }
  },
  methods: {
    submitOrder() {
      if (this.name && this.phone && this.address) {
        if (this.phone.length < 18) {
          this.errorMessage = 'Введите полный номер телефона';
          return;
        }
        this.errorMessage = '';
        this.$router.push('/order-success');
      } else {
        this.errorMessage = 'Пожалуйста, заполните все поля';
      }
    }
  }
};
</script>

<style scoped>
.checkout-page {
  max-width: 600px;
  margin: 0 auto;
  padding: 2rem;
  background: #fdfaf5;
  border-radius: 12px;
}

h1 {
  text-align: center;
  color: #4e342e;
}

.checkout-form {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.form-group {
  display: flex;
  flex-direction: column;
}

label {
  margin-bottom: 0.3rem;
  font-weight: 600;
}

input,
textarea {
  padding: 0.6rem;
  border: 1px solid #ccc;
  border-radius: 8px;
  font-size: 1rem;
}

textarea {
  resize: vertical;
}

.submit-btn {
  padding: 0.8rem;
  background-color: #38b000;
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 1.1rem;
  cursor: pointer;
}

.submit-btn:hover {
  background-color: #2b9348;
}

.error {
  color: red;
  margin-top: 1rem;
  text-align: center;
}
</style>
