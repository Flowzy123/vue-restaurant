<template>
  <div class="cart-page">
    <h1 class="title">🛒 Ваша корзина</h1>

    <div v-if="cartItems.length === 0" class="empty">Корзина пуста 🌴</div>

    <div v-else class="cart-list">
      <div v-for="(item, index) in cartItems" :key="index" class="cart-item">
        <img :src="item.image" alt="food" class="item-image" />
        <div class="item-info">
          <h3>{{ item.title }}</h3>
          <p class="desc">{{ item.description }}</p>
          <div class="ingredients">
            <strong>Ингредиенты:</strong>
            <ul>
              <li v-for="(desc, ing) in item.ingredientsDetailed" :key="ing">
                <strong>{{ ing }}:</strong> {{ desc }}
              </li>
            </ul>
          </div>
          <p>Цена: {{ item.price }} ₽</p>
          <label>
            Количество:
            <input
              type="number"
              min="1"
              v-model.number="item.quantity"
              @change="updateQuantity(index, item.quantity)"
            />
          </label>
        </div>
        <button class="remove-btn" @click="removeItem(index)">Удалить</button>
      </div>

      <div class="total">
        Итого: <strong>{{ totalPrice }} ₽</strong>
      </div>

      <router-link to="/checkout">
        <button class="checkout-btn">Оформить заказ</button>
      </router-link>
    </div>
  </div>
</template>

<script>
import { store } from '../store.js';

export default {
  name: 'Cart',
  computed: {
    cartItems() {
      return store.cartItems;
    },
    totalPrice() {
      return store.cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
    }
  },
  methods: {
    removeItem(index) {
      store.cartItems.splice(index, 1);
    },
    updateQuantity(index, quantity) {
      if (quantity < 1 || isNaN(quantity)) {
        store.cartItems[index].quantity = 1;
      } else {
        store.cartItems[index].quantity = quantity;
      }
    }
  }
};
</script>

<style scoped>
.cart-page {
  max-width: 800px;
  margin: 0 auto;
  padding: 2rem;
  background: #fefae0;
  border-radius: 16px;
  box-shadow: 0 0 10px rgba(255, 195, 0, 0.2);
}

.title {
  text-align: center;
  font-size: 2rem;
  color: #fa8231;
  margin-bottom: 1.5rem;
}

.empty {
  text-align: center;
  font-size: 1.2rem;
  color: #777;
}

.cart-list {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.cart-item {
  display: flex;
  gap: 1.5rem;
  align-items: flex-start;
  background: #fff8dc;
  padding: 1rem;
  border-radius: 12px;
  border: 1px solid #ffe082;
}

.item-image {
  width: 120px;
  height: 100px;
  object-fit: cover;
  border-radius: 12px;
  flex-shrink: 0;
}

.item-info {
  flex-grow: 1;
  max-width: calc(100% - 140px);
}

.desc {
  font-size: 0.9rem;
  color: #555;
  margin: 0.3rem 0;
}

/* Ингредиенты в виде списка */
.ingredients {
  font-size: 0.85rem;
  color: #555;
  margin-bottom: 0.5rem;
}

.ingredients ul {
  padding-left: 1.2rem;
  margin: 0.3rem 0;
}

.ingredients li {
  margin-bottom: 0.2rem;
  line-height: 1.3;
}

.remove-btn {
  background: #ff6b6b;
  border: none;
  color: white;
  padding: 0.5rem 1rem;
  border-radius: 8px;
  cursor: pointer;
  height: fit-content;
  align-self: start;
  outline: none;        /* Убираем стандартное подсвечивание */
  box-shadow: none;
  transition: background-color 0.3s ease;
}

.remove-btn:focus {
  outline: none;
  box-shadow: none;
}

.remove-btn:hover {
  background: #e63946;
}

.total {
  font-size: 1.3rem;
  text-align: right;
  margin-top: 1rem;
  color: #333;
}

.checkout-btn {
  width: 100%;
  margin-top: 1rem;
  padding: 0.8rem;
  font-size: 1.1rem;
  background: #38b000;
  color: white;
  border: none;
  border-radius: 12px;
  cursor: pointer;
}

.checkout-btn:hover {
  background: #2b9348;
}

input[type='number'] {
  width: 60px;
  padding: 4px 6px;
  margin-left: 6px;
  border: 1px solid #ccc;
  border-radius: 6px;
  font-size: 1rem;
}
</style>
