<template>
  <!-- Навигационная панель -->
  <nav class="nav-bar">
    <div class="nav-container">
      <router-link to="/" class="nav-link">Главная</router-link>
      <router-link to="/menu" class="nav-link">Меню</router-link>
      <router-link to="/rules" class="nav-link">Правила</router-link>
      <router-link to="/cart" class="nav-link">Корзина</router-link>
    </div>
  </nav>

  <!-- Контент -->
  <router-view class="page-content" />
</template>

<style scoped>
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap');

.nav-bar {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 50px;
  background: linear-gradient(to right, #ffe6b3, #ffd1a1); /* мягкий пляжный градиент */
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  display: flex;
  align-items: center;
  z-index: 1000;
  font-family: 'Inter', sans-serif;
  backdrop-filter: blur(4px);
  border-bottom: 1px solid rgba(255, 255, 255, 0.3);
}

.nav-container {
  display: flex;
  justify-content: space-around;
  align-items: center;
  max-width: 1200px;
  width: 100%;
  margin: 0 auto;
  padding: 0 30px;
}

.nav-link {
  position: relative;
  color: #3c2f2f; /* тёплый коричнево-песочный */
  font-weight: 600;
  font-size: 1.05rem;
  text-decoration: none;
  padding: 10px 8px;
  transition: color 0.3s ease;
}

.nav-link::after {
  content: "";
  position: absolute;
  left: 0;
  bottom: 4px;
  width: 100%;
  height: 2px;
  background-color: #ff8a5b; /* коралловая линия */
  transform: scaleX(0);
  transform-origin: left;
  transition: transform 0.3s ease;
}

.nav-link:hover {
  color: #ff8a5b;
}

.nav-link:hover::after {
  transform: scaleX(1);
}

.page-content {
  padding-top: 70px; /* смещение под навбар */
}
</style>
